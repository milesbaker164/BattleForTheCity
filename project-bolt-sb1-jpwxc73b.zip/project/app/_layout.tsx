import { useEffect } from 'react';
import { Redirect, Stack, useRootNavigation, useRouter, useSegments } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useFrameworkReady } from '@/hooks/useFrameworkReady';
import { supabase } from '@/lib/supabase';

function useProtectedRoute(user: boolean) {
  const segments = useSegments();
  const router = useRouter();
  const rootNavigation = useRootNavigation();

  useEffect(() => {
    const inAuthGroup = segments[0] === '(auth)';
    const inTabsGroup = segments[0] === '(tabs)';

    if (!rootNavigation?.isReady()) return;

    if (
      // If the user is not signed in and the initial segment is not anything in the auth group.
      !user &&
      !inAuthGroup
    ) {
      // Redirect to the sign-in page.
      router.replace('/sign-in');
    } else if (user && inAuthGroup) {
      // Redirect away from the sign-in page.
      router.replace('/');
    }
  }, [user, segments, rootNavigation?.isReady()]);
}

export default function RootLayout() {
  useFrameworkReady();
  const [user, setUser] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(!!session);
    });

    supabase.auth.onAuthStateChange((_event, session) => {
      setUser(!!session);
    });
  }, []);

  useProtectedRoute(user);

  return (
    <>
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="(tabs)" />
        <Stack.Screen name="(auth)" />
        <Stack.Screen name="+not-found" />
      </Stack>
      <StatusBar style="light" />
    </>
  );
}