import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity, Dimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Feather } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';

const { width } = Dimensions.get('window');

export default function HomeScreen() {
  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      <ScrollView style={styles.scrollView} showsVerticalScrollIndicator={false}>
        <View style={styles.header}>
          <LinearGradient
            colors={['rgba(0,0,0,0.8)', 'transparent']}
            style={styles.headerGradient}
          />
          <Text style={styles.headerTitle}>CITY WARFARE</Text>
          <View style={styles.headerButtons}>
            <TouchableOpacity style={styles.iconButton}>
              <Feather name="bell" size={24} color="#FFFFFF" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.iconButton}>
              <Feather name="settings" size={24} color="#FFFFFF" />
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.featuredMatch}>
          <Text style={styles.sectionTitle}>FEATURED BATTLE</Text>
          <View style={styles.featuredCard}>
            <Image
              source={{ uri: 'https://images.pexels.com/photos/2674914/pexels-photo-2674914.jpeg' }}
              style={styles.featuredImage}
            />
            <LinearGradient
              colors={['transparent', 'rgba(0,0,0,0.8)']}
              style={styles.featuredGradient}
            />
            <View style={styles.featuredContent}>
              <Text style={styles.featuredCity}>NEW YORK</Text>
              <Text style={styles.featuredMode}>TEAM DEATHMATCH</Text>
              <TouchableOpacity style={styles.playButton}>
                <Text style={styles.playButtonText}>PLAY NOW</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>

        <View style={styles.events}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>LIVE EVENTS</Text>
            <TouchableOpacity>
              <Text style={styles.seeAllText}>See All</Text>
            </TouchableOpacity>
          </View>
          
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.eventsScroll}>
            {[
              { id: 1, title: 'Weekend Tournament', time: '2h 45m', image: 'https://images.pexels.com/photos/1036657/pexels-photo-1036657.jpeg' },
              { id: 2, title: 'City Domination', time: '1d 12h', image: 'https://images.pexels.com/photos/2677398/pexels-photo-2677398.jpeg' },
              { id: 3, title: 'Sniper Challenge', time: '3d 8h', image: 'https://images.pexels.com/photos/2111714/pexels-photo-2111714.jpeg' },
            ].map(event => (
              <TouchableOpacity key={event.id} style={styles.eventCard}>
                <Image source={{ uri: event.image }} style={styles.eventImage} />
                <LinearGradient
                  colors={['transparent', 'rgba(0,0,0,0.9)']}
                  style={styles.eventGradient}
                />
                <View style={styles.eventContent}>
                  <Text style={styles.eventTitle}>{event.title}</Text>
                  <View style={styles.eventTimeContainer}>
                    <Feather name="clock" size={12} color="#E73C76" />
                    <Text style={styles.eventTime}>{event.time}</Text>
                  </View>
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        <View style={styles.news}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>NEWS & UPDATES</Text>
            <TouchableOpacity>
              <Text style={styles.seeAllText}>See All</Text>
            </TouchableOpacity>
          </View>
          
          {[
            { id: 1, title: 'New San Francisco Map Coming Soon', date: 'May 15, 2025' },
            { id: 2, title: 'Balance Updates for Assault Rifles', date: 'May 10, 2025' },
            { id: 3, title: 'Weekend XP Boost Event', date: 'May 8, 2025' },
          ].map(item => (
            <TouchableOpacity key={item.id} style={styles.newsItem}>
              <View style={styles.newsContent}>
                <Text style={styles.newsTitle}>{item.title}</Text>
                <Text style={styles.newsDate}>{item.date}</Text>
              </View>
              <Feather name="chevron-right" size={20} color="#8E8E93" />
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
  },
  scrollView: {
    flex: 1,
  },
  header: {
    height: 200,
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
    backgroundColor: '#2A2A2A',
  },
  headerGradient: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    height: 100,
  },
  headerTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 32,
    color: '#FFFFFF',
    letterSpacing: 2,
  },
  headerButtons: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  iconButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 10,
  },
  featuredMatch: {
    padding: 20,
  },
  sectionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: '#FFFFFF',
    marginBottom: 15,
  },
  featuredCard: {
    height: 200,
    borderRadius: 10,
    overflow: 'hidden',
    backgroundColor: '#2A2A2A',
  },
  featuredImage: {
    width: '100%',
    height: '100%',
    position: 'absolute',
  },
  featuredGradient: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    height: 150,
  },
  featuredContent: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: 20,
  },
  featuredCity: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
    color: '#FFFFFF',
    letterSpacing: 1,
  },
  featuredMode: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#E73C76',
    marginBottom: 15,
  },
  playButton: {
    backgroundColor: '#E73C76',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 5,
    alignSelf: 'flex-start',
  },
  playButtonText: {
    fontFamily: 'Inter-Bold',
    fontSize: 14,
    color: '#FFFFFF',
  },
  events: {
    padding: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  seeAllText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#E73C76',
  },
  eventsScroll: {
    marginLeft: -5,
  },
  eventCard: {
    width: width * 0.7,
    height: 150,
    marginHorizontal: 5,
    borderRadius: 10,
    overflow: 'hidden',
    backgroundColor: '#2A2A2A',
  },
  eventImage: {
    width: '100%',
    height: '100%',
    position: 'absolute',
  },
  eventGradient: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    height: 80,
  },
  eventContent: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: 15,
  },
  eventTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: '#FFFFFF',
    marginBottom: 5,
  },
  eventTimeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  eventTime: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#FFFFFF',
    marginLeft: 5,
  },
  news: {
    padding: 20,
    paddingBottom: 100,
  },
  newsItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 15,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.1)',
  },
  newsContent: {
    flex: 1,
    marginRight: 10,
  },
  newsTitle: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: '#FFFFFF',
    marginBottom: 5,
  },
  newsDate: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#8E8E93',
  },
});