import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, Dimensions } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';

const { width } = Dimensions.get('window');

const weapons = [
  { 
    id: 1, 
    name: 'Tactical Rifle', 
    type: 'Assault Rifle',
    damage: 75,
    accuracy: 85,
    range: 70,
    image: 'https://images.pexels.com/photos/1049303/pexels-photo-1049303.jpeg'
  },
  { 
    id: 2, 
    name: 'Shadow SMG', 
    type: 'Sub Machine Gun',
    damage: 60,
    accuracy: 70,
    range: 45,
    image: 'https://images.pexels.com/photos/1458501/pexels-photo-1458501.jpeg'
  },
  { 
    id: 3, 
    name: 'Eagle Eye', 
    type: 'Sniper Rifle',
    damage: 95,
    accuracy: 90,
    range: 95,
    image: 'https://images.pexels.com/photos/9246026/pexels-photo-9246026.jpeg'
  },
  { 
    id: 4, 
    name: 'Doom Shotgun', 
    type: 'Shotgun',
    damage: 90,
    accuracy: 50,
    range: 30,
    image: 'https://images.pexels.com/photos/45260/bullet-cartridge-weapon-gun-45260.jpeg'
  },
];

const gadgets = [
  { id: 1, name: 'Frag Grenade', description: 'Explosive damage in a radius' },
  { id: 2, name: 'Smoke Screen', description: 'Creates visual cover' },
  { id: 3, name: 'Healing Kit', description: 'Restore health over time' },
  { id: 4, name: 'Recon Drone', description: 'Scout ahead for enemies' },
];

export default function LoadoutScreen() {
  const [selectedWeapon, setSelectedWeapon] = useState(1);
  const [selectedTab, setSelectedTab] = useState('weapons');
  const [selectedGadget, setSelectedGadget] = useState(1);
  
  const renderWeaponsTab = () => (
    <View>
      <Text style={styles.sectionTitle}>PRIMARY WEAPON</Text>
      
      <ScrollView 
        horizontal 
        showsHorizontalScrollIndicator={false}
        style={styles.weaponsScroll}
      >
        {weapons.map(weapon => (
          <TouchableOpacity 
            key={weapon.id}
            style={[
              styles.weaponCard,
              selectedWeapon === weapon.id && styles.selectedWeaponCard
            ]}
            onPress={() => setSelectedWeapon(weapon.id)}
          >
            <Image source={{ uri: weapon.image }} style={styles.weaponImage} />
            <View style={styles.weaponInfo}>
              <Text style={styles.weaponName}>{weapon.name}</Text>
              <Text style={styles.weaponType}>{weapon.type}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
      
      <View style={styles.weaponDetails}>
        {weapons.filter(w => w.id === selectedWeapon).map(weapon => (
          <View key={weapon.id}>
            <View style={styles.weaponHeader}>
              <View>
                <Text style={styles.selectedWeaponName}>{weapon.name}</Text>
                <Text style={styles.selectedWeaponType}>{weapon.type}</Text>
              </View>
              <TouchableOpacity style={styles.upgradeButton}>
                <Text style={styles.upgradeButtonText}>UPGRADE</Text>
              </TouchableOpacity>
            </View>
            
            <View style={styles.statsContainer}>
              <View style={styles.statItem}>
                <Text style={styles.statLabel}>Damage</Text>
                <View style={styles.statBar}>
                  <View style={[styles.statFill, { width: `${weapon.damage}%` }]} />
                </View>
                <Text style={styles.statValue}>{weapon.damage}</Text>
              </View>
              
              <View style={styles.statItem}>
                <Text style={styles.statLabel}>Accuracy</Text>
                <View style={styles.statBar}>
                  <View style={[styles.statFill, { width: `${weapon.accuracy}%` }]} />
                </View>
                <Text style={styles.statValue}>{weapon.accuracy}</Text>
              </View>
              
              <View style={styles.statItem}>
                <Text style={styles.statLabel}>Range</Text>
                <View style={styles.statBar}>
                  <View style={[styles.statFill, { width: `${weapon.range}%` }]} />
                </View>
                <Text style={styles.statValue}>{weapon.range}</Text>
              </View>
            </View>
            
            <View style={styles.attachments}>
              <Text style={styles.attachmentsTitle}>ATTACHMENTS</Text>
              <View style={styles.attachmentSlots}>
                {['Scope', 'Barrel', 'Magazine', 'Grip'].map((slot, index) => (
                  <TouchableOpacity key={index} style={styles.attachmentSlot}>
                    <Feather name="plus" size={20} color="#8E8E93" />
                    <Text style={styles.attachmentSlotName}>{slot}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          </View>
        ))}
      </View>
    </View>
  );
  
  const renderGadgetsTab = () => (
    <View>
      <Text style={styles.sectionTitle}>TACTICAL GADGETS</Text>
      <Text style={styles.sectionSubtitle}>Select up to 2 gadgets</Text>
      
      <View style={styles.gadgetsContainer}>
        {gadgets.map(gadget => (
          <TouchableOpacity 
            key={gadget.id}
            style={[
              styles.gadgetCard,
              selectedGadget === gadget.id && styles.selectedGadgetCard
            ]}
            onPress={() => setSelectedGadget(gadget.id)}
          >
            <View style={styles.gadgetIconContainer}>
              <Feather 
                name={
                  gadget.id === 1 ? 'target' : 
                  gadget.id === 2 ? 'cloud' : 
                  gadget.id === 3 ? 'plus-circle' : 'eye'
                } 
                size={24} 
                color={selectedGadget === gadget.id ? '#FFFFFF' : '#8E8E93'} 
              />
            </View>
            <View style={styles.gadgetInfo}>
              <Text style={[
                styles.gadgetName,
                selectedGadget === gadget.id && styles.selectedGadgetText
              ]}>
                {gadget.name}
              </Text>
              <Text style={styles.gadgetDescription}>{gadget.description}</Text>
            </View>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
  
  const renderPerksTab = () => (
    <View style={styles.perksContainer}>
      <Text style={styles.sectionTitle}>COMBAT PERKS</Text>
      <Text style={styles.sectionSubtitle}>Select perks to enhance your abilities</Text>
      
      <View style={styles.perkCategories}>
        {[
          { name: 'Speed', icon: 'zap', description: 'Move 15% faster' },
          { name: 'Resilience', icon: 'shield', description: 'Take 10% less damage' },
          { name: 'Scavenger', icon: 'package', description: 'Find more ammo' },
          { name: 'Ghost', icon: 'eye-off', description: 'Invisible to enemy radar' },
          { name: 'Quick Hands', icon: 'refresh-cw', description: 'Reload 20% faster' },
          { name: 'Tracker', icon: 'navigation', description: 'See enemy footprints' },
        ].map((perk, index) => (
          <TouchableOpacity key={index} style={styles.perkCard}>
            <View style={styles.perkIcon}>
              <Feather name={perk.icon} size={24} color="#E73C76" />
            </View>
            <View style={styles.perkInfo}>
              <Text style={styles.perkName}>{perk.name}</Text>
              <Text style={styles.perkDescription}>{perk.description}</Text>
            </View>
            <TouchableOpacity style={styles.perkSelectButton}>
              <Text style={styles.perkSelectText}>SELECT</Text>
            </TouchableOpacity>
          </TouchableOpacity>
        ))}
      </View>
    </View>
  );
  
  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      <View style={styles.header}>
        <Text style={styles.headerTitle}>LOADOUT</Text>
      </View>
      
      <View style={styles.tabsContainer}>
        {['weapons', 'gadgets', 'perks'].map(tab => (
          <TouchableOpacity 
            key={tab}
            style={[
              styles.tabButton,
              selectedTab === tab && styles.activeTabButton
            ]}
            onPress={() => setSelectedTab(tab)}
          >
            <Text style={[
              styles.tabText,
              selectedTab === tab && styles.activeTabText
            ]}>
              {tab.toUpperCase()}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
      
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {selectedTab === 'weapons' && renderWeaponsTab()}
        {selectedTab === 'gadgets' && renderGadgetsTab()}
        {selectedTab === 'perks' && renderPerksTab()}
        
        <TouchableOpacity style={styles.saveButton}>
          <Text style={styles.saveButtonText}>SAVE LOADOUT</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
    backgroundColor: '#1A1A1A',
  },
  headerTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
    color: '#FFFFFF',
  },
  tabsContainer: {
    flexDirection: 'row',
    backgroundColor: '#1A1A1A',
    paddingHorizontal: 20,
    paddingBottom: 15,
  },
  tabButton: {
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderRadius: 20,
    marginRight: 10,
  },
  activeTabButton: {
    backgroundColor: '#E73C76',
  },
  tabText: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#8E8E93',
  },
  activeTabText: {
    color: '#FFFFFF',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  sectionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: '#FFFFFF',
    marginTop: 5,
  },
  sectionSubtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#8E8E93',
    marginBottom: 15,
  },
  weaponsScroll: {
    marginVertical: 15,
  },
  weaponCard: {
    width: 150,
    height: 180,
    backgroundColor: '#2A2A2A',
    borderRadius: 10,
    marginRight: 10,
    overflow: 'hidden',
  },
  selectedWeaponCard: {
    borderWidth: 2,
    borderColor: '#E73C76',
  },
  weaponImage: {
    width: '100%',
    height: 120,
  },
  weaponInfo: {
    padding: 10,
  },
  weaponName: {
    fontFamily: 'Inter-Bold',
    fontSize: 14,
    color: '#FFFFFF',
  },
  weaponType: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#8E8E93',
  },
  weaponDetails: {
    backgroundColor: '#2A2A2A',
    borderRadius: 10,
    padding: 15,
    marginBottom: 20,
  },
  weaponHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  selectedWeaponName: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: '#FFFFFF',
  },
  selectedWeaponType: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#8E8E93',
  },
  upgradeButton: {
    backgroundColor: '#E73C76',
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderRadius: 5,
  },
  upgradeButtonText: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#FFFFFF',
  },
  statsContainer: {
    marginBottom: 20,
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  statLabel: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#FFFFFF',
    width: 80,
  },
  statBar: {
    flex: 1,
    height: 8,
    backgroundColor: '#1A1A1A',
    borderRadius: 4,
    marginHorizontal: 10,
  },
  statFill: {
    height: 8,
    backgroundColor: '#E73C76',
    borderRadius: 4,
  },
  statValue: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#FFFFFF',
    width: 30,
    textAlign: 'right',
  },
  attachments: {
    marginBottom: 10,
  },
  attachmentsTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: '#FFFFFF',
    marginBottom: 10,
  },
  attachmentSlots: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  attachmentSlot: {
    width: '48%',
    height: 60,
    backgroundColor: '#1A1A1A',
    borderRadius: 8,
    marginBottom: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  attachmentSlotName: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#8E8E93',
    marginTop: 5,
  },
  gadgetsContainer: {
    marginVertical: 15,
  },
  gadgetCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#2A2A2A',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
  },
  selectedGadgetCard: {
    backgroundColor: '#E73C76',
  },
  gadgetIconContainer: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#1A1A1A',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  gadgetInfo: {
    flex: 1,
  },
  gadgetName: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: '#FFFFFF',
  },
  selectedGadgetText: {
    color: '#FFFFFF',
  },
  gadgetDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#8E8E93',
  },
  perksContainer: {
    marginVertical: 15,
  },
  perkCategories: {
    marginTop: 15,
  },
  perkCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#2A2A2A',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
  },
  perkIcon: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#1A1A1A',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  perkInfo: {
    flex: 1,
  },
  perkName: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: '#FFFFFF',
  },
  perkDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#8E8E93',
  },
  perkSelectButton: {
    backgroundColor: '#1A1A1A',
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderRadius: 5,
  },
  perkSelectText: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#E73C76',
  },
  saveButton: {
    backgroundColor: '#E73C76',
    paddingVertical: 15,
    borderRadius: 10,
    marginVertical: 20,
    marginBottom: 100,
  },
  saveButtonText: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: '#FFFFFF',
    textAlign: 'center',
  },
});