import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, Dimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Feather } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';

const { width } = Dimensions.get('window');
const ITEM_WIDTH = width * 0.75;

const cities = [
  { id: 1, name: 'New York', image: 'https://images.pexels.com/photos/2224861/pexels-photo-2224861.jpeg' },
  { id: 2, name: 'Los Angeles', image: 'https://images.pexels.com/photos/1444083/pexels-photo-1444083.jpeg' },
  { id: 3, name: 'Chicago', image: 'https://images.pexels.com/photos/2143486/pexels-photo-2143486.jpeg' },
  { id: 4, name: 'Miami', image: 'https://images.pexels.com/photos/2337800/pexels-photo-2337800.jpeg' },
  { id: 5, name: 'Seattle', image: 'https://images.pexels.com/photos/3964368/pexels-photo-3964368.jpeg' },
];

const gameModes = [
  { id: 1, name: 'Team Deathmatch', players: '5v5', time: '10 min' },
  { id: 2, name: 'Battle Royale', players: '30', time: '20 min' },
  { id: 3, name: 'Capture the Flag', players: '4v4', time: '15 min' },
  { id: 4, name: 'Domination', players: '6v6', time: '12 min' },
];

export default function BattleScreen() {
  const [selectedCity, setSelectedCity] = useState(1);
  const [selectedMode, setSelectedMode] = useState(1);
  
  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      <View style={styles.header}>
        <Text style={styles.headerTitle}>BATTLE</Text>
        <TouchableOpacity style={styles.friendsButton}>
          <Feather name="users" size={20} color="#FFFFFF" />
          <Text style={styles.friendsButtonText}>INVITE FRIENDS</Text>
        </TouchableOpacity>
      </View>
      
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <Text style={styles.sectionTitle}>SELECT BATTLEFIELD</Text>
        <Text style={styles.sectionSubtitle}>Choose from 20 American cities</Text>
        
        <ScrollView 
          horizontal 
          pagingEnabled
          snapToInterval={ITEM_WIDTH + 10}
          decelerationRate="fast"
          showsHorizontalScrollIndicator={false}
          style={styles.citiesScroll}
          contentContainerStyle={styles.citiesContent}
        >
          {cities.map(city => (
            <TouchableOpacity 
              key={city.id}
              style={[
                styles.cityCard,
                selectedCity === city.id && styles.selectedCityCard
              ]}
              onPress={() => setSelectedCity(city.id)}
            >
              <Image source={{ uri: city.image }} style={styles.cityImage} />
              <LinearGradient
                colors={['transparent', 'rgba(0,0,0,0.8)']}
                style={styles.cityGradient}
              />
              <View style={styles.cityContent}>
                <Text style={styles.cityName}>{city.name}</Text>
                {selectedCity === city.id && (
                  <View style={styles.selectedIndicator}>
                    <Feather name="check" size={16} color="#FFFFFF" />
                  </View>
                )}
              </View>
            </TouchableOpacity>
          ))}
        </ScrollView>
        
        <Text style={styles.sectionTitle}>GAME MODE</Text>
        
        <View style={styles.gameModes}>
          {gameModes.map(mode => (
            <TouchableOpacity 
              key={mode.id}
              style={[
                styles.modeCard,
                selectedMode === mode.id && styles.selectedModeCard
              ]}
              onPress={() => setSelectedMode(mode.id)}
            >
              <View style={styles.modeIconContainer}>
                <Feather 
                  name={
                    mode.id === 1 ? 'users' : 
                    mode.id === 2 ? 'target' : 
                    mode.id === 3 ? 'flag' : 'grid'
                  } 
                  size={24} 
                  color={selectedMode === mode.id ? '#FFFFFF' : '#8E8E93'} 
                />
              </View>
              <View style={styles.modeContent}>
                <Text style={[
                  styles.modeName,
                  selectedMode === mode.id && styles.selectedModeText
                ]}>
                  {mode.name}
                </Text>
                <Text style={styles.modeDetails}>
                  {mode.players} · {mode.time}
                </Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>
        
        <View style={styles.matchSettings}>
          <Text style={styles.sectionTitle}>MATCH SETTINGS</Text>
          
          <View style={styles.settingItem}>
            <Text style={styles.settingLabel}>Difficulty</Text>
            <View style={styles.settingOptions}>
              {['Easy', 'Medium', 'Hard'].map((level, index) => (
                <TouchableOpacity 
                  key={index}
                  style={[
                    styles.difficultyOption,
                    index === 1 && styles.selectedDifficulty
                  ]}
                >
                  <Text style={[
                    styles.difficultyText,
                    index === 1 && styles.selectedDifficultyText
                  ]}>
                    {level}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
          
          <View style={styles.settingItem}>
            <Text style={styles.settingLabel}>Time of Day</Text>
            <View style={styles.timeOption}>
              <Feather name="sun" size={20} color="#E73C76" />
              <Text style={styles.timeText}>Day</Text>
              <Feather name="chevron-down" size={20} color="#8E8E93" />
            </View>
          </View>
          
          <View style={styles.settingItem}>
            <Text style={styles.settingLabel}>Weather</Text>
            <View style={styles.timeOption}>
              <Feather name="cloud" size={20} color="#E73C76" />
              <Text style={styles.timeText}>Clear</Text>
              <Feather name="chevron-down" size={20} color="#8E8E93" />
            </View>
          </View>
        </View>
        
        <TouchableOpacity style={styles.startButton}>
          <Text style={styles.startButtonText}>START BATTLE</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
    backgroundColor: '#1A1A1A',
  },
  headerTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 24,
    color: '#FFFFFF',
  },
  friendsButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#2A2A2A',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 20,
  },
  friendsButtonText: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#FFFFFF',
    marginLeft: 5,
  },
  content: {
    flex: 1,
    padding: 20,
  },
  sectionTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: '#FFFFFF',
    marginTop: 10,
  },
  sectionSubtitle: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#8E8E93',
    marginBottom: 15,
  },
  citiesScroll: {
    marginVertical: 15,
  },
  citiesContent: {
    paddingHorizontal: 5,
  },
  cityCard: {
    width: ITEM_WIDTH,
    height: 180,
    marginHorizontal: 5,
    borderRadius: 10,
    overflow: 'hidden',
    backgroundColor: '#2A2A2A',
  },
  selectedCityCard: {
    borderWidth: 2,
    borderColor: '#E73C76',
  },
  cityImage: {
    width: '100%',
    height: '100%',
    position: 'absolute',
  },
  cityGradient: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    height: 100,
  },
  cityContent: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: 15,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  cityName: {
    fontFamily: 'Inter-Bold',
    fontSize: 22,
    color: '#FFFFFF',
  },
  selectedIndicator: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: '#E73C76',
    justifyContent: 'center',
    alignItems: 'center',
  },
  gameModes: {
    marginVertical: 15,
  },
  modeCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#2A2A2A',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
  },
  selectedModeCard: {
    backgroundColor: '#E73C76',
  },
  modeIconContainer: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#1A1A1A',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  modeContent: {
    flex: 1,
  },
  modeName: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: '#FFFFFF',
    marginBottom: 5,
  },
  selectedModeText: {
    color: '#FFFFFF',
  },
  modeDetails: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#8E8E93',
  },
  matchSettings: {
    marginVertical: 15,
  },
  settingItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginVertical: 10,
  },
  settingLabel: {
    fontFamily: 'Inter-Regular',
    fontSize: 16,
    color: '#FFFFFF',
  },
  settingOptions: {
    flexDirection: 'row',
  },
  difficultyOption: {
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 15,
    backgroundColor: '#2A2A2A',
    marginLeft: 5,
  },
  selectedDifficulty: {
    backgroundColor: '#E73C76',
  },
  difficultyText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#8E8E93',
  },
  selectedDifficultyText: {
    color: '#FFFFFF',
  },
  timeOption: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#2A2A2A',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 15,
  },
  timeText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#FFFFFF',
    marginHorizontal: 5,
  },
  startButton: {
    backgroundColor: '#E73C76',
    paddingVertical: 15,
    borderRadius: 10,
    marginVertical: 20,
    marginBottom: 100,
  },
  startButtonText: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: '#FFFFFF',
    textAlign: 'center',
  },
});