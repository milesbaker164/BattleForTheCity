import React, { useState } from 'react';
import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView } from 'react-native';
import { Feather } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';

export default function ProfileScreen() {
  const [activeTab, setActiveTab] = useState('stats');
  
  const renderStatsTab = () => (
    <View style={styles.statsContainer}>
      <View style={styles.statsRow}>
        <View style={styles.statCard}>
          <Text style={styles.statValue}>247</Text>
          <Text style={styles.statLabel}>MATCHES</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statValue}>56%</Text>
          <Text style={styles.statLabel}>WIN RATE</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statValue}>2.8</Text>
          <Text style={styles.statLabel}>K/D RATIO</Text>
        </View>
      </View>
      
      <View style={styles.performanceCard}>
        <View style={styles.performanceHeader}>
          <Text style={styles.performanceTitle}>PERFORMANCE</Text>
          <View style={styles.timePeriod}>
            <Text style={styles.timePeriodText}>Last 30 days</Text>
            <Feather name="chevron-down" size={16} color="#8E8E93" />
          </View>
        </View>
        
        <View style={styles.performanceStats}>
          <View style={styles.performanceItem}>
            <View style={styles.performanceInfo}>
              <Text style={styles.performanceLabel}>Accuracy</Text>
              <Text style={styles.performanceValue}>72%</Text>
            </View>
            <View style={styles.performanceBar}>
              <View style={[styles.performanceFill, { width: '72%' }]} />
            </View>
          </View>
          
          <View style={styles.performanceItem}>
            <View style={styles.performanceInfo}>
              <Text style={styles.performanceLabel}>Headshots</Text>
              <Text style={styles.performanceValue}>38%</Text>
            </View>
            <View style={styles.performanceBar}>
              <View style={[styles.performanceFill, { width: '38%' }]} />
            </View>
          </View>
          
          <View style={styles.performanceItem}>
            <View style={styles.performanceInfo}>
              <Text style={styles.performanceLabel}>Win Rate</Text>
              <Text style={styles.performanceValue}>56%</Text>
            </View>
            <View style={styles.performanceBar}>
              <View style={[styles.performanceFill, { width: '56%' }]} />
            </View>
          </View>
          
          <View style={styles.performanceItem}>
            <View style={styles.performanceInfo}>
              <Text style={styles.performanceLabel}>Kills Per Match</Text>
              <Text style={styles.performanceValue}>12.5</Text>
            </View>
            <View style={styles.performanceBar}>
              <View style={[styles.performanceFill, { width: '62%' }]} />
            </View>
          </View>
        </View>
      </View>
      
      <View style={styles.recentMatchesCard}>
        <Text style={styles.recentMatchesTitle}>RECENT MATCHES</Text>
        
        {[
          { id: 1, map: 'New York', mode: 'Team Deathmatch', result: 'Victory', kills: 14, deaths: 5, date: '2h ago' },
          { id: 2, map: 'Chicago', mode: 'Domination', result: 'Victory', kills: 12, deaths: 8, date: '5h ago' },
          { id: 3, map: 'Miami', mode: 'Battle Royale', result: 'Defeat', kills: 7, deaths: 1, date: '1d ago' },
        ].map(match => (
          <View key={match.id} style={styles.matchItem}>
            <View style={styles.matchInfo}>
              <Text style={styles.matchMap}>{match.map}</Text>
              <Text style={styles.matchMode}>{match.mode}</Text>
              <Text 
                style={[
                  styles.matchResult,
                  match.result === 'Victory' ? styles.victoryText : styles.defeatText
                ]}
              >
                {match.result}
              </Text>
            </View>
            <View style={styles.matchStats}>
              <Text style={styles.matchKD}>{match.kills}/{match.deaths}</Text>
              <Text style={styles.matchDate}>{match.date}</Text>
            </View>
          </View>
        ))}
        
        <TouchableOpacity style={styles.viewAllButton}>
          <Text style={styles.viewAllText}>VIEW ALL MATCHES</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
  
  const renderAchievementsTab = () => (
    <View style={styles.achievementsContainer}>
      {[
        { id: 1, name: 'First Blood', description: 'Get your first kill', icon: 'award', complete: true, progress: '1/1' },
        { id: 2, name: 'Marksman', description: 'Get 100 headshots', icon: 'crosshair', complete: true, progress: '100/100' },
        { id: 3, name: 'Urban Legend', description: 'Win in all city maps', icon: 'map', complete: false, progress: '15/20' },
        { id: 4, name: 'Arsenal Master', description: 'Get kills with all weapon types', icon: 'target', complete: false, progress: '6/8' },
        { id: 5, name: 'Team Player', description: 'Win 50 team matches', icon: 'users', complete: false, progress: '32/50' },
        { id: 6, name: 'Survivor', description: 'Win a match without dying', icon: 'shield', complete: true, progress: '1/1' },
      ].map(achievement => (
        <View 
          key={achievement.id} 
          style={[
            styles.achievementCard,
            achievement.complete && styles.completedAchievement
          ]}
        >
          <View style={styles.achievementIcon}>
            <Feather name={achievement.icon} size={24} color={achievement.complete ? '#FFFFFF' : '#8E8E93'} />
          </View>
          <View style={styles.achievementInfo}>
            <View style={styles.achievementHeader}>
              <Text style={styles.achievementName}>{achievement.name}</Text>
              {achievement.complete && <Feather name="check" size={16} color="#FFFFFF" />}
            </View>
            <Text style={styles.achievementDescription}>{achievement.description}</Text>
            <View style={styles.achievementProgress}>
              <View style={styles.progressBar}>
                <View 
                  style={[
                    styles.progressFill, 
                    { 
                      width: achievement.complete ? '100%' : 
                      achievement.id === 3 ? '75%' : 
                      achievement.id === 4 ? '75%' : 
                      '64%'
                    }
                  ]} 
                />
              </View>
              <Text style={styles.progressText}>{achievement.progress}</Text>
            </View>
          </View>
        </View>
      ))}
    </View>
  );
  
  const renderInventoryTab = () => (
    <View style={styles.inventoryContainer}>
      <Text style={styles.inventoryTitle}>CHARACTER SKINS</Text>
      
      <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.skinsScroll}>
        {[
          { id: 1, name: 'Urban Commando', rarity: 'Epic', image: 'https://images.pexels.com/photos/9779091/pexels-photo-9779091.jpeg' },
          { id: 2, name: 'Desert Ranger', rarity: 'Rare', image: 'https://images.pexels.com/photos/9779078/pexels-photo-9779078.jpeg' },
          { id: 3, name: 'Arctic Hunter', rarity: 'Legendary', image: 'https://images.pexels.com/photos/3329111/pexels-photo-3329111.jpeg' },
        ].map(skin => (
          <View key={skin.id} style={styles.skinCard}>
            <Image source={{ uri: skin.image }} style={styles.skinImage} />
            <View style={styles.skinInfo}>
              <Text style={styles.skinName}>{skin.name}</Text>
              <Text 
                style={[
                  styles.skinRarity,
                  skin.rarity === 'Epic' ? styles.epicRarity :
                  skin.rarity === 'Legendary' ? styles.legendaryRarity :
                  styles.rareRarity
                ]}
              >
                {skin.rarity}
              </Text>
            </View>
          </View>
        ))}
      </ScrollView>
      
      <Text style={[styles.inventoryTitle, { marginTop: 20 }]}>WEAPON BLUEPRINTS</Text>
      
      <View style={styles.blueprintsContainer}>
        {[
          { id: 1, name: 'Toxic Thunder', weapon: 'Tactical Rifle', rarity: 'Epic' },
          { id: 2, name: 'Ghost Protocol', weapon: 'Shadow SMG', rarity: 'Rare' },
          { id: 3, name: 'Frost Bite', weapon: 'Eagle Eye', rarity: 'Legendary' },
          { id: 4, name: 'Hellfire', weapon: 'Doom Shotgun', rarity: 'Epic' },
        ].map(blueprint => (
          <View key={blueprint.id} style={styles.blueprintCard}>
            <View style={styles.blueprintHeader}>
              <View 
                style={[
                  styles.rarityIndicator,
                  blueprint.rarity === 'Epic' ? styles.epicIndicator :
                  blueprint.rarity === 'Legendary' ? styles.legendaryIndicator :
                  styles.rareIndicator
                ]} 
              />
              <Text style={styles.blueprintWeapon}>{blueprint.weapon}</Text>
            </View>
            <Text style={styles.blueprintName}>{blueprint.name}</Text>
            <TouchableOpacity style={styles.equipButton}>
              <Text style={styles.equipButtonText}>EQUIP</Text>
            </TouchableOpacity>
          </View>
        ))}
      </View>
    </View>
  );
  
  return (
    <View style={styles.container}>
      <StatusBar style="light" />
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <View style={styles.profileInfo}>
            <Image 
              source={{ uri: 'https://images.pexels.com/photos/18914614/pexels-photo-18914614.jpeg' }} 
              style={styles.profileImage} 
            />
            <View style={styles.nameContainer}>
              <Text style={styles.username}>SHADOW_STRIKER</Text>
              <View style={styles.levelContainer}>
                <Text style={styles.levelText}>LEVEL 42</Text>
              </View>
              <View style={styles.rankContainer}>
                <Feather name="award" size={14} color="#FFD700" />
                <Text style={styles.rankText}>PLATINUM</Text>
              </View>
            </View>
          </View>
          <TouchableOpacity style={styles.editButton}>
            <Feather name="edit-2" size={16} color="#FFFFFF" />
          </TouchableOpacity>
        </View>
      </View>
      
      <View style={styles.tabs}>
        {['stats', 'achievements', 'inventory'].map(tab => (
          <TouchableOpacity 
            key={tab}
            style={[styles.tab, activeTab === tab && styles.activeTab]}
            onPress={() => setActiveTab(tab)}
          >
            <Text 
              style={[
                styles.tabText,
                activeTab === tab && styles.activeTabText
              ]}
            >
              {tab.toUpperCase()}
            </Text>
          </TouchableOpacity>
        ))}
      </View>
      
      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {activeTab === 'stats' && renderStatsTab()}
        {activeTab === 'achievements' && renderAchievementsTab()}
        {activeTab === 'inventory' && renderInventoryTab()}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#121212',
  },
  header: {
    paddingTop: 60,
    paddingBottom: 20,
    backgroundColor: '#1A1A1A',
  },
  headerContent: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  profileInfo: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  profileImage: {
    width: 70,
    height: 70,
    borderRadius: 35,
    borderWidth: 3,
    borderColor: '#E73C76',
  },
  nameContainer: {
    marginLeft: 15,
  },
  username: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: '#FFFFFF',
    marginBottom: 5,
  },
  levelContainer: {
    backgroundColor: '#E73C76',
    paddingVertical: 3,
    paddingHorizontal: 8,
    borderRadius: 10,
    alignSelf: 'flex-start',
    marginBottom: 5,
  },
  levelText: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#FFFFFF',
  },
  rankContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  rankText: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#FFD700',
    marginLeft: 5,
  },
  editButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  tabs: {
    flexDirection: 'row',
    backgroundColor: '#1A1A1A',
    paddingHorizontal: 20,
    paddingBottom: 15,
  },
  tab: {
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderRadius: 20,
    marginRight: 10,
  },
  activeTab: {
    backgroundColor: '#E73C76',
  },
  tabText: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#8E8E93',
  },
  activeTabText: {
    color: '#FFFFFF',
  },
  content: {
    flex: 1,
    padding: 20,
  },
  statsContainer: {
    marginBottom: 80,
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  statCard: {
    width: '31%',
    backgroundColor: '#2A2A2A',
    borderRadius: 10,
    padding: 15,
    alignItems: 'center',
  },
  statValue: {
    fontFamily: 'Inter-Bold',
    fontSize: 20,
    color: '#FFFFFF',
    marginBottom: 5,
  },
  statLabel: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#8E8E93',
  },
  performanceCard: {
    backgroundColor: '#2A2A2A',
    borderRadius: 10,
    padding: 15,
    marginBottom: 20,
  },
  performanceHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  performanceTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: '#FFFFFF',
  },
  timePeriod: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#1A1A1A',
    paddingVertical: 5,
    paddingHorizontal: 10,
    borderRadius: 15,
  },
  timePeriodText: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#8E8E93',
    marginRight: 5,
  },
  performanceStats: {},
  performanceItem: {
    marginBottom: 15,
  },
  performanceInfo: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 5,
  },
  performanceLabel: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#FFFFFF',
  },
  performanceValue: {
    fontFamily: 'Inter-Bold',
    fontSize: 14,
    color: '#FFFFFF',
  },
  performanceBar: {
    height: 8,
    backgroundColor: '#1A1A1A',
    borderRadius: 4,
  },
  performanceFill: {
    height: 8,
    backgroundColor: '#E73C76',
    borderRadius: 4,
  },
  recentMatchesCard: {
    backgroundColor: '#2A2A2A',
    borderRadius: 10,
    padding: 15,
  },
  recentMatchesTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: '#FFFFFF',
    marginBottom: 15,
  },
  matchItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  matchInfo: {
    flex: 1,
  },
  matchMap: {
    fontFamily: 'Inter-Bold',
    fontSize: 14,
    color: '#FFFFFF',
  },
  matchMode: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#8E8E93',
    marginBottom: 5,
  },
  matchResult: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
  },
  victoryText: {
    color: '#4CAF50',
  },
  defeatText: {
    color: '#F44336',
  },
  matchStats: {
    alignItems: 'flex-end',
  },
  matchKD: {
    fontFamily: 'Inter-Bold',
    fontSize: 14,
    color: '#FFFFFF',
    marginBottom: 5,
  },
  matchDate: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#8E8E93',
  },
  viewAllButton: {
    backgroundColor: '#1A1A1A',
    paddingVertical: 10,
    borderRadius: 5,
    marginTop: 15,
    alignItems: 'center',
  },
  viewAllText: {
    fontFamily: 'Inter-Regular',
    fontSize: 14,
    color: '#E73C76',
  },
  achievementsContainer: {
    marginBottom: 80,
  },
  achievementCard: {
    flexDirection: 'row',
    backgroundColor: '#2A2A2A',
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
  },
  completedAchievement: {
    borderLeftWidth: 4,
    borderLeftColor: '#E73C76',
  },
  achievementIcon: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#1A1A1A',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  achievementInfo: {
    flex: 1,
  },
  achievementHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  achievementName: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: '#FFFFFF',
    marginBottom: 5,
  },
  achievementDescription: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#8E8E93',
    marginBottom: 10,
  },
  achievementProgress: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  progressBar: {
    flex: 1,
    height: 5,
    backgroundColor: '#1A1A1A',
    borderRadius: 3,
    marginRight: 10,
  },
  progressFill: {
    height: 5,
    backgroundColor: '#E73C76',
    borderRadius: 3,
  },
  progressText: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#8E8E93',
  },
  inventoryContainer: {
    marginBottom: 80,
  },
  inventoryTitle: {
    fontFamily: 'Inter-Bold',
    fontSize: 18,
    color: '#FFFFFF',
    marginBottom: 15,
  },
  skinsScroll: {
    marginBottom: 20,
  },
  skinCard: {
    width: 150,
    height: 200,
    backgroundColor: '#2A2A2A',
    borderRadius: 10,
    overflow: 'hidden',
    marginRight: 10,
  },
  skinImage: {
    width: '100%',
    height: 150,
  },
  skinInfo: {
    padding: 10,
  },
  skinName: {
    fontFamily: 'Inter-Bold',
    fontSize: 14,
    color: '#FFFFFF',
    marginBottom: 5,
  },
  skinRarity: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
  },
  epicRarity: {
    color: '#9C27B0',
  },
  legendaryRarity: {
    color: '#FFD700',
  },
  rareRarity: {
    color: '#2196F3',
  },
  blueprintsContainer: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },
  blueprintCard: {
    width: '48%',
    backgroundColor: '#2A2A2A',
    borderRadius: 10,
    padding: 15,
    marginBottom: 10,
  },
  blueprintHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  rarityIndicator: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 8,
  },
  epicIndicator: {
    backgroundColor: '#9C27B0',
  },
  legendaryIndicator: {
    backgroundColor: '#FFD700',
  },
  rareIndicator: {
    backgroundColor: '#2196F3',
  },
  blueprintWeapon: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#8E8E93',
  },
  blueprintName: {
    fontFamily: 'Inter-Bold',
    fontSize: 16,
    color: '#FFFFFF',
    marginBottom: 10,
  },
  equipButton: {
    backgroundColor: '#1A1A1A',
    paddingVertical: 8,
    borderRadius: 5,
    alignItems: 'center',
  },
  equipButtonText: {
    fontFamily: 'Inter-Regular',
    fontSize: 12,
    color: '#E73C76',
  },
});